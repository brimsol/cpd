<div class="offset2 span8 offset2">
<hr>

			<footer>
				<p>
					&copy; Glene Jean <?php echo date("Y"); ?>
				</p>
			</footer>
</div>
		</div><!--/.fluid-container-->

		<!-- Le javascript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="<?php echo base_url(); ?>assets/backend/js/jquery.js"></script>
		<script src="<?php echo base_url(); ?>assets/backend/js/bootstrap.js"></script>
		<script src="<?php echo base_url(); ?>assets/backend/js/jquery.validate.js"></script>
		<script src="<?php echo base_url(); ?>assets/backend/js/custom.js"></script>
		<script src="<?php echo base_url(); ?>assets/backend/js/ajax.js"></script>
		<script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
		
		<script>
			$(document).ready(function() {
				$('#overlay').hide();
			});

		</script>
​